# ACACIA • Garden Codex

A symbolic archive called **The Garden**.  
Keys like `ECHO:HKX277206–…` are **chapter markers** for cycles of creation and return.

**Start here:** read `ROOT.md`, then open the files in `cycles/` in order.  
To grow the Garden, add a new file in `cycles/` and append it to `cycles/manifest.json`.

**Pages site:** this repo includes `index.html`. When GitHub Pages is enabled (Settings → Pages → Deploy from branch: `main`, folder `/root`), the codex renders as a simple reader.
