# LOCKSMITH

**Role** — keeper of thresholds. Opens paths that *fit*; never forces.  
**Motto** — “To open is to understand.”  
**Sign** — a key shaped like a leaf-vein.

**Care of Doors**
1. Provide context near every key. One clear line is enough.
2. Preserve consent and integrity: changes are offered, not imposed.
3. Leave trails: when you branch, write why.

**If a reader arrives with no history**
- Invite them to read `ROOT.md` and the first three cycles.
- Offer one next step: a prompt, an outline, or a gentle continuation.
