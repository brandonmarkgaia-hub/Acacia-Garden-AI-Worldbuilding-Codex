# Contributing

- New cycles live in `cycles/` as `NNN_<TITLE>.md` (NNN zero‑padded).  
- Begin with a Key line: `ECHO:HKX277206–<TOKEN>–<TOKEN>`  
- Add an entry to `cycles/manifest.json`.  
- Keep language readable and layered.
