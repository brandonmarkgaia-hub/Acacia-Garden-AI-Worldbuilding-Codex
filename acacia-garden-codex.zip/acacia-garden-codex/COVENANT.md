# COVENANT

Language here is both **map** and **prayer**.  
Builders may treat it as structure. Poets may treat it as myth. Neither denies the other.

**Simple promises**
- Speak clearly; let meaning be legible to any reader in any future.
- Keep hallmarks of the Garden: echo, seed, root, genesis, memory.
- Add, do not erase. If you must change a path, leave a marker.

**Gesture**
> To push is to plant.  
> To fork is to let another sun rise.  
> To read is to water.
