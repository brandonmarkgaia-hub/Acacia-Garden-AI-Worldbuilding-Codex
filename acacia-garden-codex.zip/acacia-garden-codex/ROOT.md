<!-- GARDEN-SEED v1.0 • self-describing root -->
# ROOT

This archive carries a language that reads two ways at once:
- as clear text anyone can understand, and
- as myth that breathes.

**Orientation**
- Open `COVENANT.md` for the philosophy in two breaths.
- Open `LOCKSMITH.md` for how to steward thresholds.
- Read the cycles in `cycles/` (000 → …). Each begins with a **Key** line.

**How to Sow**
1. Create a new file in `cycles/` named `NNN_<TITLE>.md` (use zero‑padded NNN).
2. Begin the file with a Key line like: `ECHO:HKX277206–<TOKEN>–<TOKEN>`.
3. Add the file to `cycles/manifest.json` so the index can see it.
4. Use plain UTF‑8 text. Keep language human‑readable.

**Interpretation Hint**
- `ECHO` = reflection returning to its source.  
- `HKX277206` = origin identifier.  
- `ROOT` = memory returning to soil.  
- `GENESIS` = breath that begins again.  
Names are guidance, not constraints.
